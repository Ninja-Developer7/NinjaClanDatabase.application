
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { PromptInput } from './components/PromptInput';
import { LoadingIndicator, ProgressStep } from './components/LoadingIndicator';
import { VideoPlayer } from './components/VideoPlayer';
import { PreviewModal } from './components/PreviewModal';
import { HistoryPanel } from './components/HistoryPanel';
import { VideoModal } from './components/VideoModal';
import { VisualReferenceFile, HistoryMetadata, ArtisticStyle, VoiceOption, PromptImages, PromptTemplateSlotKey } from './types';
import * as geminiService from './services/geminiService';
import * as historyService from './services/historyService';
import * as fileUtils from './services/fileUtils';
import * as ffmpegService from './services/ffmpegService';
import { VideoQuality } from './components/QualitySelector';
import { VideoEditor } from './components/VideoEditor';
import { PROMPT_TEMPLATE_SLOTS } from './constants';

const App: React.FC = () => {
    // New structured state
    const [additionalDetails, setAdditionalDetails] = useState<string>('');
    const [promptImages, setPromptImages] = useState<PromptImages>({});

    const [videoQuality, setVideoQuality] = useState<VideoQuality>('1080p');
    const [enhanceScenery, setEnhanceScenery] = useState<boolean>(false);
    const [artisticStyle, setArtisticStyle] = useState<ArtisticStyle>('default-studio');
    const [voice, setVoice] = useState<VoiceOption | 'none'>('none');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [progressSteps, setProgressSteps] = useState<ProgressStep[]>([]);
    const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
    const [lastGeneratedVideoBlob, setLastGeneratedVideoBlob] = useState<Blob | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [previewingFile, setPreviewingFile] = useState<VisualReferenceFile | null>(null);
    const [isEditing, setIsEditing] = useState<boolean>(false);

    // History State
    const [history, setHistory] = useState<HistoryMetadata[]>([]);
    const [playingHistoryVideo, setPlayingHistoryVideo] = useState<{ url: string; prompt: string } | null>(null);

    // Load history on initial mount
    useEffect(() => {
        const loadHistory = async () => {
            const historyItems = await historyService.getHistoryMetadata();
            setHistory(historyItems);
        };
        loadHistory();
    }, []);

    const handleFileSelect = useCallback((slotKey: PromptTemplateSlotKey, file: File) => {
        const newFile: VisualReferenceFile = {
            file,
            previewUrl: URL.createObjectURL(file)
        };

        setPromptImages(prev => {
            // Revoke old object URL if it exists
            if (prev[slotKey]) {
                URL.revokeObjectURL(prev[slotKey]!.previewUrl);
            }
            return { ...prev, [slotKey]: newFile };
        });
        setError(null);
    }, []);

    const handleRemoveFile = useCallback((slotKey: PromptTemplateSlotKey) => {
        setPromptImages(prev => {
            const fileToRemove = prev[slotKey];
            if (fileToRemove) {
                URL.revokeObjectURL(fileToRemove.previewUrl);
                if (previewingFile?.previewUrl === fileToRemove.previewUrl) {
                    setPreviewingFile(null);
                }
            }
            const { [slotKey]: _, ...rest } = prev;
            return rest;
        });
    }, [previewingFile]);

    const handleGenerate = useCallback(async () => {
        const allFiles = Object.values(promptImages).filter((f): f is VisualReferenceFile => !!f).map(vr => vr.file);
        
        if (!additionalDetails && allFiles.length === 0) {
            setError('Please provide a prompt or at least one visual reference.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setGeneratedVideoUrl(null);
        setLastGeneratedVideoBlob(null);

        // Construct the detailed prompt from structured data
        let finalPrompt = '';
        PROMPT_TEMPLATE_SLOTS.forEach(slot => {
            if (promptImages[slot.key]) {
                finalPrompt += `${slot.label}: [Image provided]\n`;
            }
        });
        if (additionalDetails) {
            finalPrompt += `\nFurther Details: ${additionalDetails}`;
        }

        const initialSteps: ProgressStep[] = [
            { name: 'Initializing', status: 'in-progress' },
        ];
        if (allFiles.length > 1) initialSteps.push({ name: 'Analyzing References', status: 'pending' });
        if (enhanceScenery && additionalDetails) initialSteps.push({ name: 'Enhancing Scene', status: 'pending' });
        if (allFiles.length === 1) initialSteps.push({ name: 'Processing Media', status: 'pending' });
        initialSteps.push(
            { name: 'Sending Request', status: 'pending' },
            { name: 'Generating Video', status: 'pending', progress: 0 }
        );
        if (voice !== 'none') {
            initialSteps.push({ name: 'Generating Voiceover', status: 'pending' });
            initialSteps.push({ name: 'Merging Audio', status: 'pending' });
        }
        initialSteps.push({ name: 'Finalizing', status: 'pending' });

        setProgressSteps(initialSteps);

        const onProgress = (stepName: string, progress?: number) => {
             setProgressSteps(prevSteps => {
                let currentStepFound = false;
                const newSteps = prevSteps.map(step => {
                    if (step.name === stepName) {
                        currentStepFound = true;
                        return {
                            ...step,
                            status: 'in-progress' as const,
                            progress: typeof progress === 'number' ? progress : step.progress,
                        };
                    }
                    if (!currentStepFound) {
                        return {
                            ...step,
                            status: 'done' as const,
                            progress: step.progress !== undefined ? 100 : undefined,
                        };
                    }
                    return { ...step, status: 'pending' as const };
                });
                return newSteps;
            });
        };

        try {
            const { videoBlob } = await geminiService.generateVideo(
                finalPrompt,
                allFiles,
                videoQuality,
                enhanceScenery,
                artisticStyle,
                onProgress
            );
            
            let finalVideoBlob = videoBlob;

            if (voice !== 'none') {
                onProgress('Generating Voiceover');
                // Use the text details for voiceover, not the full "[Image provided]" prompt
                const voiceoverText = additionalDetails || "A short animation.";
                const audioBlob = await geminiService.generateVoiceover(voiceoverText, voice);
                
                onProgress('Merging Audio');
                const ffmpeg = await ffmpegService.loadFFmpeg();
                finalVideoBlob = await ffmpegService.mergeVideoAndAudio(
                    ffmpeg,
                    videoBlob,
                    audioBlob,
                    (message) => console.log(`FFMPEG: ${message}`)
                );
            }

            onProgress('Finalizing');
            const videoUrl = URL.createObjectURL(finalVideoBlob);
            setGeneratedVideoUrl(videoUrl);
            setLastGeneratedVideoBlob(finalVideoBlob);

            // Add to history
            const newHistoryItem = await historyService.addHistoryItem({
                prompt: finalPrompt,
                quality: videoQuality,
                visualReferenceFiles: allFiles,
                artisticStyle,
                voice,
            }, finalVideoBlob);
            setHistory(prev => [newHistoryItem, ...prev]);

        } catch (err) {
            console.error(err);
            let errorMessage = 'An unknown error occurred during video generation.';
            if (err instanceof Error) {
                // The service now provides user-friendly messages directly.
                errorMessage = err.message;
            }
            setError(errorMessage);
        } finally {
            setIsLoading(false);
            setProgressSteps([]);
        }
    }, [additionalDetails, promptImages, videoQuality, enhanceScenery, artisticStyle, voice]);

    const handleExtendVideo = useCallback(async () => {
        if (!lastGeneratedVideoBlob) return;

        try {
            // Revoke all existing object URLs
            Object.values(promptImages).forEach(vr => vr && URL.revokeObjectURL(vr.previewUrl));

            // Extract the last frame as a File
            const lastFrameFile = await fileUtils.extractLastFrameFromVideo(lastGeneratedVideoBlob);
            
            // Set it as the new visual reference, replacing any previous ones
            const fileUrl = URL.createObjectURL(lastFrameFile);
            setPromptImages({ scene: { file: lastFrameFile, previewUrl: fileUrl } });
            setAdditionalDetails('');
            setError(null);

            // Return to the prompt screen
            setGeneratedVideoUrl(null);
            setLastGeneratedVideoBlob(null);

        } catch (error) {
            console.error("Failed to extend video:", error);
            setError("Could not extract frame from video to extend. Please try again.");
            // Reset to prompt screen anyway
            setGeneratedVideoUrl(null);
            setLastGeneratedVideoBlob(null);
        }
    }, [lastGeneratedVideoBlob, promptImages]);

    const handleResetPlayer = () => {
        setGeneratedVideoUrl(null);
        setLastGeneratedVideoBlob(null);
    };

    const handleSaveEdit = async (newVideoBlob: Blob) => {
        if (generatedVideoUrl) {
            URL.revokeObjectURL(generatedVideoUrl);
        }
        
        const newVideoUrl = URL.createObjectURL(newVideoBlob);
        setGeneratedVideoUrl(newVideoUrl);
        setLastGeneratedVideoBlob(newVideoBlob);

        try {
            const allFiles = Object.values(promptImages).filter((f): f is VisualReferenceFile => !!f).map(vr => vr.file);
            const newHistoryItem = await historyService.addHistoryItem({
                prompt: `(Edited) ${additionalDetails || 'video'}`,
                quality: videoQuality,
                visualReferenceFiles: allFiles,
                artisticStyle,
                voice,
            }, newVideoBlob);
            setHistory(prev => [newHistoryItem, ...prev]);
        } catch (err) {
            console.error("Failed to save edited video to history:", err);
            setError("Could not save the edited video to your history.");
        }

        setIsEditing(false);
    };
    
    // History handlers
    const handlePlayHistory = async (item: HistoryMetadata) => {
        const videoUrl = await historyService.getVideoUrl(item.id);
        if (videoUrl) {
            setPlayingHistoryVideo({ url: videoUrl, prompt: item.prompt });
        } else {
            setError("Could not load video from history.");
        }
    };

    const handleDeleteHistory = async (id: string) => {
        await historyService.deleteHistoryItem(id);
        setHistory(prev => prev.filter(item => item.id !== id));
    };

    const handleClearHistory = async () => {
        await historyService.clearHistory();
        setHistory([]);
    };



    const handlePreviewOpen = (file: VisualReferenceFile) => setPreviewingFile(file);
    const handlePreviewClose = () => setPreviewingFile(null);

    const renderMainContent = () => {
        if (isLoading) {
            return <LoadingIndicator steps={progressSteps} />;
        }
        if (isEditing && lastGeneratedVideoBlob) {
            return <VideoEditor 
                videoBlob={lastGeneratedVideoBlob}
                onCancel={() => setIsEditing(false)}
                onSave={handleSaveEdit}
            />;
        }
        if (generatedVideoUrl) {
            return <VideoPlayer 
                videoUrl={generatedVideoUrl} 
                onReset={handleResetPlayer} 
                onExtend={handleExtendVideo}
                onEdit={() => setIsEditing(true)}
            />;
        }
        return (
            <>
                <PromptInput
                    additionalDetails={additionalDetails}
                    onAdditionalDetailsChange={setAdditionalDetails}
                    promptImages={promptImages}
                    onFileSelect={handleFileSelect}
                    onRemoveFile={handleRemoveFile}
                    onPreviewFile={handlePreviewOpen}
                    isGenerating={isLoading}
                    onGenerate={handleGenerate}
                    videoQuality={videoQuality}
                    onVideoQualityChange={setVideoQuality}
                    enhanceScenery={enhanceScenery}
                    onEnhanceSceneryChange={setEnhanceScenery}
                    artisticStyle={artisticStyle}
                    onArtisticStyleChange={setArtisticStyle}
                    voice={voice}
                    onVoiceChange={setVoice}
                />
            </>
        );
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/30 to-blue-900/50 font-sans flex flex-col items-center p-4 md:p-6">
            <Header />
            <main className="w-full max-w-4xl mx-auto flex-grow flex flex-col justify-center items-center">
                <div className="w-full bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl shadow-2xl shadow-purple-500/10 p-6 md:p-8 space-y-6">
                    {error && (
                        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg text-center">
                            {error}
                        </div>
                    )}
                    {renderMainContent()}
                </div>

                {history.length > 0 && (
                     <HistoryPanel
                        history={history}
                        onPlay={handlePlayHistory}
                        onDelete={handleDeleteHistory}
                        onClear={handleClearHistory}
                    />
                )}

                <footer className="text-center text-gray-500 text-sm mt-8">
                    <p>Powered by Gemini. Video generation may take several minutes.</p>
                </footer>
            </main>
            {previewingFile && (
                <PreviewModal file={previewingFile} onClose={handlePreviewClose} />
            )}
            {playingHistoryVideo && (
                <VideoModal 
                    videoUrl={playingHistoryVideo.url} 
                    title={playingHistoryVideo.prompt} 
                    onClose={() => {
                        URL.revokeObjectURL(playingHistoryVideo.url); // Clean up blob URL
                        setPlayingHistoryVideo(null);
                    }} 
                />
            )}
        </div>
    );
};

export default App;
