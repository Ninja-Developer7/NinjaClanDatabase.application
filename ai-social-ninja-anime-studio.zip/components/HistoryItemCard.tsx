import React, { useState } from 'react';
import { HistoryMetadata, ArtisticStyle, VoiceOption } from '../types';
import { PlayIcon } from './icons/PlayIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { TrashIcon } from './icons/TrashIcon';
import * as historyService from '../services/historyService';
import { MicrophoneIcon } from './icons/MicrophoneIcon';

interface HistoryItemCardProps {
    item: HistoryMetadata;
    onPlay: () => void;
    onDelete: () => void;
}

const formatTimeAgo = (timestamp: number): string => {
    const now = new Date();
    const seconds = Math.floor((now.getTime() - timestamp) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";

    if (seconds < 10) return "just now";
    
    return Math.floor(seconds) + " seconds ago";
};

const getStyleDisplayName = (style: ArtisticStyle): string => {
    switch (style) {
        case 'default-studio': return 'Studio';
        case 'shonen-action': return 'Shonen';
        case 'shojo-romance': return 'Shojo';
        case 'cyberpunk-grit': return 'Cyberpunk';
        case 'fantasy-epic': return 'Fantasy';
        case 'retro-anime': return 'Retro';
        default: return 'Style';
    }
};

const getVoiceDisplayName = (voice: VoiceOption | 'none'): string => {
    if (voice === 'none') return 'No Voice';
    return voice.charAt(0).toUpperCase() + voice.slice(1);
}

export const HistoryItemCard: React.FC<HistoryItemCardProps> = ({ item, onPlay, onDelete }) => {
    const [isDownloading, setIsDownloading] = useState(false);
    
    const handleDownload = async () => {
        setIsDownloading(true);
        const url = await historyService.getVideoUrl(item.id);
        if (url) {
            const a = document.createElement('a');
            a.href = url;
            a.download = `video-${item.id}.mp4`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url); // Clean up
        }
        setIsDownloading(false);
    };

    return (
        <div className="bg-gray-800/70 border border-gray-700 rounded-xl flex flex-col overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10 hover:border-purple-800/50 transform hover:-translate-y-1">
            <button onClick={onPlay} className="relative aspect-video w-full group bg-gray-900" title="Play Video">
                 {item.visualReferenceThumbnail ? (
                    <img src={item.visualReferenceThumbnail} alt="Visual reference" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                ) : (
                    <div className="w-full h-full flex items-center justify-center">
                        <span className="text-xs text-gray-400">No Visuals</span>
                    </div>
                )}
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <PlayIcon className="w-10 h-10 text-white" />
                </div>
            </button>
           
            <div className="p-4 flex flex-col flex-grow">
                <p className="text-sm font-semibold text-gray-200 flex-grow h-10 line-clamp-2" title={item.prompt}>{item.prompt}</p>
                 <div className="text-xs text-gray-400 mt-2 flex items-center justify-between flex-wrap gap-y-2">
                   <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-purple-400 bg-purple-900/50 px-2 py-1 rounded-full">{item.quality.toUpperCase()}</span>
                        <span className="font-bold text-blue-400 bg-blue-900/50 px-2 py-1 rounded-full">{getStyleDisplayName(item.artisticStyle)}</span>
                        {item.voice !== 'none' && (
                             <span className="font-bold text-teal-400 bg-teal-900/50 px-2 py-1 rounded-full flex items-center gap-1">
                                <MicrophoneIcon className="w-3 h-3" />
                                {getVoiceDisplayName(item.voice)}
                            </span>
                        )}
                   </div>
                   <span className="text-xs text-gray-500">{formatTimeAgo(item.timestamp)}</span>
                </div>
            </div>

            <div className="flex items-center justify-end space-x-2 p-3 bg-gray-900/50 border-t border-gray-700/50">
                <button onClick={handleDownload} disabled={isDownloading} className="p-2 text-gray-300 rounded-full hover:bg-green-600 hover:text-white transition-colors disabled:opacity-50" title="Download Video">
                    <DownloadIcon className="w-5 h-5" />
                </button>
                <button onClick={onDelete} className="p-2 text-gray-300 rounded-full hover:bg-red-600 hover:text-white transition-colors" title="Delete Video">
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
};