
import React, { useRef } from 'react';
import { PromptTemplateSlotKey, VisualReferenceFile } from '../types';
import { MAX_FILE_SIZE, ACCEPTED_FILE_TYPES } from '../constants';
import { XIcon } from './icons/XIcon';
import { MaximizeIcon } from './icons/MaximizeIcon';
import { UploadIcon } from './icons/UploadIcon';

interface ImageSlotProps {
    slotKey: PromptTemplateSlotKey;
    label: string;
    visualReference?: VisualReferenceFile;
    onFileSelect: (slotKey: PromptTemplateSlotKey, file: File) => void;
    onRemove: (slotKey: PromptTemplateSlotKey) => void;
    onPreview: (file: VisualReferenceFile) => void;
    disabled: boolean;
}

export const ImageSlot: React.FC<ImageSlotProps> = ({ slotKey, label, visualReference, onFileSelect, onRemove, onPreview, disabled }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            if (file.size > MAX_FILE_SIZE) {
                alert(`File "${file.name}" is too large. Maximum size is ${MAX_FILE_SIZE / 1024 / 1024}MB.`);
                if (fileInputRef.current) fileInputRef.current.value = '';
                return;
            }
            onFileSelect(slotKey, file);
        }
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const triggerFilePicker = () => {
        if (!disabled) {
            fileInputRef.current?.click();
        }
    };

    const handleRemoveClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onRemove(slotKey);
    };

    const handlePreviewClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (visualReference) {
            onPreview(visualReference);
        }
    }

    const isVideo = visualReference?.file.type.startsWith('video/');

    return (
        <div className="flex flex-col">
            <label className="text-sm font-medium text-gray-300 mb-1">{label}</label>
            <div
                onClick={triggerFilePicker}
                className={`relative aspect-video w-full rounded-lg border-2 border-dashed transition-all duration-200 flex items-center justify-center group
                ${visualReference ? 'border-purple-600 bg-gray-900' : 'border-gray-600 hover:border-purple-500 bg-gray-900/50 hover:bg-gray-900'}
                ${disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
            >
                {visualReference ? (
                    <>
                        {isVideo ? (
                             <video src={visualReference.previewUrl} className="w-full h-full object-cover rounded-md" muted loop autoPlay playsInline />
                        ) : (
                            <img src={visualReference.previewUrl} alt={label} className="w-full h-full object-cover rounded-md" />
                        )}
                         <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center space-x-2 rounded-md">
                            <button onClick={handlePreviewClick} className="p-2 bg-gray-800/70 rounded-full text-white hover:bg-blue-600" title="Preview media">
                                <MaximizeIcon className="w-5 h-5" />
                            </button>
                            <button onClick={handleRemoveClick} className="p-2 bg-gray-800/70 rounded-full text-white hover:bg-red-600" title="Remove media">
                                <XIcon />
                            </button>
                         </div>
                    </>
                ) : (
                    <div className="text-center text-gray-500 group-hover:text-purple-400 transition-colors">
                        <UploadIcon className="w-6 h-6 mx-auto" />
                        <p className="text-xs mt-1">Click to upload</p>
                    </div>
                )}
            </div>
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept={Object.keys(ACCEPTED_FILE_TYPES).join(',')}
                className="hidden"
                disabled={disabled}
            />
        </div>
    );
};
