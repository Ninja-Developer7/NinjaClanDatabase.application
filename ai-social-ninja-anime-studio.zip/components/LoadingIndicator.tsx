
import React from 'react';
import { CheckIcon } from './icons/CheckIcon';

const StepSpinner: React.FC = () => (
    <div className="w-5 h-5 border-2 border-t-2 border-gray-400 border-t-purple-500 rounded-full animate-spin"></div>
);

const PendingIcon: React.FC = () => (
    <div className="w-5 h-5 border-2 border-gray-500 rounded-full"></div>
);

export interface ProgressStep {
    name: string;
    status: 'pending' | 'in-progress' | 'done';
    progress?: number;
}

interface LoadingIndicatorProps {
    steps: ProgressStep[];
}

export const LoadingIndicator: React.FC<LoadingIndicatorProps> = ({ steps }) => {
    
    const getStepIcon = (status: ProgressStep['status']) => {
        switch (status) {
            case 'done':
                return <CheckIcon className="w-5 h-5 text-green-400" />;
            case 'in-progress':
                return <StepSpinner />;
            case 'pending':
            default:
                return <PendingIcon />;
        }
    };

    const getStepTextStyle = (status: ProgressStep['status']) => {
        switch (status) {
            case 'done':
                return 'text-gray-400 line-through';
            case 'in-progress':
                return 'text-purple-300 font-semibold';
            case 'pending':
            default:
                return 'text-gray-500';
        }
    };

    return (
        <div className="flex flex-col items-center justify-center p-8 space-y-6 min-h-[250px]">
            <div className="w-16 h-16 border-4 border-t-4 border-gray-600 border-t-purple-500 rounded-full animate-spin"></div>
            <h3 className="text-xl font-semibold text-gray-200">Generating Your Masterpiece...</h3>
            
            <div className="w-full max-w-sm space-y-4 pt-4 border-t border-gray-700/50">
                {steps.map((step, index) => (
                    <div key={index} className="flex items-start space-x-4 animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                        <div className="flex-shrink-0 mt-0.5">
                            {getStepIcon(step.status)}
                        </div>
                        <div className="flex-grow">
                            <p className={`text-base transition-colors duration-300 ${getStepTextStyle(step.status)}`}>
                                {step.name}
                                {step.status === 'in-progress' && typeof step.progress === 'number' && (
                                    <span className="text-sm font-mono text-gray-400 ml-2">{step.progress}%</span>
                                )}
                            </p>
                            {step.status === 'in-progress' && typeof step.progress === 'number' && (
                                <div className="w-full bg-gray-700/50 rounded-full h-1.5 mt-1.5 overflow-hidden">
                                    <div 
                                        className="bg-gradient-to-r from-purple-500 to-blue-500 h-1.5 rounded-full transition-all duration-500 ease-linear" 
                                        style={{ width: `${step.progress}%` }}
                                    ></div>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
            
            <p className="text-sm text-gray-500 pt-4">This process can take several minutes. Please don't close this window.</p>

            <style>{`
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .animate-spin {
                    animation: spin 1s linear infinite;
                }
                @keyframes fade-in-up {
                    0% {
                        opacity: 0;
                        transform: translateY(10px);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.3s ease-out forwards;
                    opacity: 0;
                }
            `}</style>
        </div>
    );
};
