
import React from 'react';
import { GenerateIcon } from './icons/GenerateIcon';
import { QualitySelector, VideoQuality } from './QualitySelector';
import { InfoIcon } from './icons/InfoIcon';
import { StyleSelector } from './StyleSelector';
import { ArtisticStyle, PromptImages, VisualReferenceFile, VoiceOption, PromptTemplateSlotKey } from '../types';
import { VoiceoverSelector } from './VoiceoverSelector';
import { PROMPT_TEMPLATE_SLOTS } from '../constants';
import { ImageSlot } from './ImageSlot';

interface PromptInputProps {
    additionalDetails: string;
    onAdditionalDetailsChange: (details: string) => void;
    promptImages: PromptImages;
    onFileSelect: (slotKey: PromptTemplateSlotKey, file: File) => void;
    onRemoveFile: (slotKey: PromptTemplateSlotKey) => void;
    onPreviewFile: (file: VisualReferenceFile) => void;
    isGenerating: boolean;
    onGenerate: () => void;
    videoQuality: VideoQuality;
    onVideoQualityChange: (quality: VideoQuality) => void;
    enhanceScenery: boolean;
    onEnhanceSceneryChange: (enabled: boolean) => void;
    artisticStyle: ArtisticStyle;
    onArtisticStyleChange: (style: ArtisticStyle) => void;
    voice: VoiceOption | 'none';
    onVoiceChange: (voice: VoiceOption | 'none') => void;
}

export const PromptInput: React.FC<PromptInputProps> = ({
    additionalDetails,
    onAdditionalDetailsChange,
    promptImages,
    onFileSelect,
    onRemoveFile,
    onPreviewFile,
    isGenerating,
    onGenerate,
    videoQuality,
    onVideoQualityChange,
    enhanceScenery,
    onEnhanceSceneryChange,
    artisticStyle,
    onArtisticStyleChange,
    voice,
    onVoiceChange,
}) => {

    const hasContent = additionalDetails.trim() !== '' || Object.keys(promptImages).length > 0;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {PROMPT_TEMPLATE_SLOTS.map(slot => (
                    <ImageSlot
                        key={slot.key}
                        slotKey={slot.key}
                        label={slot.label}
                        visualReference={promptImages[slot.key]}
                        onFileSelect={onFileSelect}
                        onRemove={onRemoveFile}
                        onPreview={onPreviewFile}
                        disabled={isGenerating}
                    />
                ))}
            </div>

            <div className="relative">
                 <label htmlFor="additional-details" className="block text-sm font-medium text-gray-300 mb-2">
                    Additional Details for the Prompt
                </label>
                <textarea
                    id="additional-details"
                    value={additionalDetails}
                    onChange={(e) => onAdditionalDetailsChange(e.target.value)}
                    placeholder="Describe the action, mood, camera angles, or any other specifics..."
                    maxLength={3000}
                    className="w-full h-28 p-4 bg-gray-900/70 border border-gray-600 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-shadow duration-300 resize-y text-gray-200 placeholder-gray-500"
                    disabled={isGenerating}
                    aria-label="Additional prompt details"
                />
            </div>
            
            <div className="flex items-center justify-between pt-2">
                 <label htmlFor="scenery-assist" className="flex items-center space-x-2 cursor-pointer group">
                    <div className="relative">
                        <input 
                            type="checkbox" 
                            id="scenery-assist" 
                            className="sr-only" 
                            checked={enhanceScenery}
                            onChange={(e) => onEnhanceSceneryChange(e.target.checked)}
                            disabled={isGenerating}
                        />
                        <div className={`block w-10 h-6 rounded-full transition-colors ${enhanceScenery ? 'bg-purple-600' : 'bg-gray-600'}`}></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${enhanceScenery ? 'translate-x-4' : ''}`}></div>
                    </div>
                    <span className={`text-sm font-medium transition-colors ${enhanceScenery ? 'text-purple-300' : 'text-gray-400'}`}>AI Scenery Assist</span>
                     <div className="relative group/tooltip">
                        <InfoIcon className="w-4 h-4 text-gray-500" />
                        <div className="absolute bottom-full mb-2 w-64 bg-gray-900 text-white text-xs rounded-lg py-2 px-3 opacity-0 group-hover/tooltip:opacity-100 transition-opacity duration-300 pointer-events-none z-10 shadow-lg border border-gray-700">
                            Let our AI assistant generate rich, detailed descriptions of backgrounds and environments for your scene based on your text prompt.
                        </div>
                    </div>
                 </label>
            </div>

             <div className="flex flex-col sm:flex-row justify-between items-center gap-4 border-t border-gray-700/50 pt-6">
                <div className="flex items-center space-x-2">
                    <StyleSelector
                        selectedStyle={artisticStyle}
                        onStyleChange={onArtisticStyleChange}
                        disabled={isGenerating}
                    />
                    <VoiceoverSelector
                        selectedVoice={voice}
                        onVoiceChange={onVoiceChange}
                        disabled={isGenerating}
                    />
                </div>
                <div className="flex items-center gap-4">
                     <QualitySelector
                        selectedQuality={videoQuality}
                        onQualityChange={onVideoQualityChange}
                        disabled={isGenerating}
                    />
                    <button
                        onClick={onGenerate}
                        disabled={isGenerating || !hasContent}
                        className="flex items-center justify-center h-12 w-12 bg-purple-600 rounded-full text-white hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500 transition-all duration-200 transform hover:scale-110 shrink-0"
                        title="Generate Video"
                        aria-label="Generate Video"
                    >
                        <GenerateIcon />
                    </button>
                </div>
            </div>
        </div>
    );
};
