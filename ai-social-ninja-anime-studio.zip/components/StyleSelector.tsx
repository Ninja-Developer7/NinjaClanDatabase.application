import React, { useState, useRef, useEffect } from 'react';
import { ArtisticStyle } from '../types';
import { PaintBrushIcon } from './icons/PaintBrushIcon';
import { CheckIcon } from './icons/CheckIcon';

export const styles: { id: ArtisticStyle; name: string; description: string }[] = [
    { id: 'default-studio', name: 'Default Studio', description: 'Lush, painted backgrounds and whimsical design (Studio Ghibli inspired).' },
    { id: 'shonen-action', name: 'Shonen Action', description: 'Dynamic, high-energy action sequences and sharp lines (Naruto, DBZ inspired).' },
    { id: 'shojo-romance', name: 'Shojo Romance', description: 'Soft, dreamy visuals, expressive characters, and pastel color palettes.' },
    { id: 'cyberpunk-grit', name: 'Cyberpunk Grit', description: 'Neon-drenched cities, high-tech details, and a dark, moody atmosphere.' },
    { id: 'fantasy-epic', name: 'Fantasy Epic', description: 'Grand landscapes, mythical creatures, detailed armor and magic effects.' },
    { id: 'retro-anime', name: 'Retro Anime', description: 'Nostalgic 80s/90s look with cel-shading and film grain (Cowboy Bebop inspired).' },
];

interface StyleSelectorProps {
    selectedStyle: ArtisticStyle;
    onStyleChange: (style: ArtisticStyle) => void;
    disabled: boolean;
}

export const StyleSelector: React.FC<StyleSelectorProps> = ({ selectedStyle, onStyleChange, disabled }) => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (styleId: ArtisticStyle) => {
        onStyleChange(styleId);
        setIsOpen(false);
    };
    
    return (
        <div className="relative" ref={menuRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                disabled={disabled}
                className="flex items-center justify-center h-10 w-10 bg-gray-700 rounded-full text-gray-300 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500 transition-all duration-200 transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Select Artistic Style"
                aria-haspopup="true"
                aria-expanded={isOpen}
            >
                <PaintBrushIcon className="w-5 h-5" />
            </button>
            {isOpen && (
                <div className="absolute bottom-12 right-0 w-72 bg-gray-800 border border-gray-700 rounded-lg shadow-lg z-10 animate-fade-in-up">
                    <div className="p-2">
                        <p className="text-sm font-semibold text-gray-200 px-2 pb-2">Artistic Style</p>
                        <ul className="space-y-1">
                            {styles.map((style) => (
                                <li key={style.id}>
                                    <button
                                        onClick={() => handleSelect(style.id)}
                                        className={`w-full text-left p-2 rounded-md hover:bg-gray-700 transition-colors duration-150 ${selectedStyle === style.id ? 'bg-purple-900/50' : ''}`}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex flex-col">
                                                <span className="text-sm font-medium text-gray-100">{style.name}</span>
                                                <span className="text-xs text-gray-400">{style.description}</span>
                                            </div>
                                            {selectedStyle === style.id && <CheckIcon className="w-5 h-5 text-purple-400 flex-shrink-0 ml-2" />}
                                        </div>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            )}
            <style>{`
                @keyframes fade-in-up { 0% { opacity: 0; transform: translateY(10px); } 100% { opacity: 1; transform: translateY(0); } }
                .animate-fade-in-up { animation: fade-in-up 0.2s ease-out; }
            `}</style>
        </div>
    );
};