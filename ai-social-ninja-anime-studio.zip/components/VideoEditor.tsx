
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ScissorsIcon } from './icons/ScissorsIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PlayIcon } from './icons/PlayIcon';
import { PauseIcon } from './icons/PauseIcon';

declare const FFmpeg: any;

interface Clip {
    id: string;
    start: number;
    end: number;
}

interface VideoEditorProps {
    videoBlob: Blob;
    onCancel: () => void;
    onSave: (newVideoBlob: Blob) => void;
}

const formatTime = (time: number) => {
    if (isNaN(time) || time < 0) return '00:00.000';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    const milliseconds = Math.floor((time * 1000) % 1000);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(3, '0')}`;
};

const Spinner: React.FC<{ message: string }> = ({ message }) => (
    <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm flex flex-col items-center justify-center z-50">
        <div className="w-16 h-16 border-4 border-t-4 border-gray-600 border-t-purple-500 rounded-full animate-spin"></div>
        <p className="mt-4 text-lg text-gray-300">{message}</p>
    </div>
);

export const VideoEditor: React.FC<VideoEditorProps> = ({ videoBlob, onCancel, onSave }) => {
    const ffmpegRef = useRef<any>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [loadingMessage, setLoadingMessage] = useState('Initializing Editor...');
    const [isReady, setIsReady] = useState(false);
    
    const [videoUrl, setVideoUrl] = useState('');
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);

    const [clips, setClips] = useState<Clip[]>([]);
    const [activeClipId, setActiveClipId] = useState<string | null>(null);
    const [previewingClipId, setPreviewingClipId] = useState<string | null>(null);

    // Refs for drag and drop logic
    const dragItem = useRef<number | null>(null);
    const dragOverItem = useRef<number | null>(null);
    
    // State for visual feedback during drag
    const [isDragging, setIsDragging] = useState(false);

    // Refs for state inside useEffect to avoid re-binding listeners
    const previewingClipIdRef = useRef(previewingClipId);
    previewingClipIdRef.current = previewingClipId;
    const clipsRef = useRef(clips);
    clipsRef.current = clips;


    const loadFFmpeg = useCallback(async () => {
        if (ffmpegRef.current) return;
        const ffmpeg = new FFmpeg.FFmpeg();
        ffmpeg.on('log', ({ message }: { message: string }) => {
            console.log(message);
        });
        setLoadingMessage('Loading Video Engine...');
        await ffmpeg.load({
            coreURL: "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js"
        });
        ffmpegRef.current = ffmpeg;
        setLoadingMessage('Processing Video...');
        await ffmpeg.writeFile('input.mp4', await FFmpeg.fetchFile(videoBlob));
        setIsReady(true);
        setIsLoading(false);
    }, [videoBlob]);

    useEffect(() => {
        loadFFmpeg();
        const url = URL.createObjectURL(videoBlob);
        setVideoUrl(url);

        const video = document.createElement('video');
        video.src = url;
        video.onloadedmetadata = () => {
            const videoDuration = video.duration;
            setDuration(videoDuration);
            const initialClip: Clip = { id: `clip_${Date.now()}`, start: 0, end: videoDuration };
            setClips([initialClip]);
            setActiveClipId(initialClip.id);
        };

        return () => {
            URL.revokeObjectURL(url);
        };
    }, [videoBlob, loadFFmpeg]);

    const handleStopPreview = useCallback(() => {
        const video = videoRef.current;
        if (!video) return;
        video.pause();
        setPreviewingClipId(null);
    }, []);

    const handlePreviewClip = (clipId: string) => {
        const video = videoRef.current;
        if (!video) return;
        const clipToPreview = clips.find(c => c.id === clipId);
        if (clipToPreview) {
            setActiveClipId(clipId);
            setPreviewingClipId(clipId);
            video.currentTime = clipToPreview.start;
            video.play();
        }
    };


    const handleSplit = () => {
        if (!activeClipId || currentTime === 0 || currentTime >= duration) return;

        const clipIndex = clips.findIndex(c => c.id === activeClipId);
        const clipToSplit = clips[clipIndex];

        if (currentTime <= clipToSplit.start || currentTime >= clipToSplit.end) {
            alert("Split point must be within the selected clip.");
            return;
        }

        const newClip1: Clip = { ...clipToSplit, end: currentTime };
        const newClip2: Clip = { ...clipToSplit, id: `clip_${Date.now()}`, start: currentTime };

        const newClips = [...clips];
        newClips.splice(clipIndex, 1, newClip1, newClip2);
        setClips(newClips);
    };

    const handleDelete = (clipId: string) => {
        setClips(prev => {
            const newClips = prev.filter(c => c.id !== clipId);
            if (newClips.length > 0 && activeClipId === clipId) {
                setActiveClipId(newClips[0].id!);
            } else if (newClips.length === 0) {
                setActiveClipId(null);
            }
            return newClips;
        });
    };
    
    const handleUpdateTime = (clipId: string, type: 'start' | 'end', value: number) => {
        setClips(clips.map(c => {
            if (c.id === clipId) {
                const updatedClip = { ...c, [type]: value };
                if (updatedClip.start >= updatedClip.end) {
                    if (type === 'start') updatedClip.start = Math.max(0, updatedClip.end - 0.01);
                    else updatedClip.end = Math.min(duration, updatedClip.start + 0.01);
                }
                updatedClip.start = Math.max(0, updatedClip.start);
                updatedClip.end = Math.min(duration, updatedClip.end);
                return updatedClip;
            }
            return c;
        }));
    };

    const handleExport = async () => {
        if (!ffmpegRef.current || clips.length === 0) return;
        setIsLoading(true);
        setLoadingMessage('Exporting Video...');
        
        try {
            const ffmpeg = ffmpegRef.current;
            const segmentFiles = [];
            for (let i = 0; i < clips.length; i++) {
                const clip = clips[i];
                const outputFilename = `segment_${i}.mp4`;
                setLoadingMessage(`Processing clip ${i + 1}/${clips.length}...`);
                await ffmpeg.exec([
                    '-ss', `${clip.start}`,
                    '-i', 'input.mp4',
                    '-to', `${clip.end}`,
                    '-c', 'copy',
                    '-avoid_negative_ts', '1',
                    outputFilename
                ]);
                segmentFiles.push(`file '${outputFilename}'`);
            }
            
            setLoadingMessage('Combining clips...');
            await ffmpeg.writeFile('concat.txt', segmentFiles.join('\n'));
            await ffmpeg.exec([
                '-f', 'concat',
                '-safe', '0',
                '-i', 'concat.txt',
                '-c', 'copy',
                'output.mp4'
            ]);

            setLoadingMessage('Finalizing...');
            const data = await ffmpeg.readFile('output.mp4');
            const newBlob = new Blob([(data as Uint8Array).buffer], { type: 'video/mp4' });
            onSave(newBlob);
        } catch (error) {
            console.error("Export failed:", error);
            alert("An error occurred during export. Check console for details.");
        } finally {
            setIsLoading(false);
        }
    };
    
    // Drag and Drop handlers
    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, position: number) => {
        dragItem.current = position;
        setTimeout(() => setIsDragging(true), 0);
    };
    
    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, position: number) => {
        dragOverItem.current = position;
        if (dragItem.current !== null && dragItem.current !== dragOverItem.current) {
            const newClips = [...clips];
            const dragItemContent = newClips.splice(dragItem.current, 1)[0];
            newClips.splice(dragOverItem.current, 0, dragItemContent);
            dragItem.current = dragOverItem.current;
            setClips(newClips);
        }
    };
    
    const handleDragEnd = () => {
        dragItem.current = null;
        dragOverItem.current = null;
        setIsDragging(false);
    };

    // Trim handle logic
    const handleTrimMouseDown = (e: React.MouseEvent<HTMLDivElement>, clipId: string, handleType: 'start' | 'end') => {
        e.preventDefault();
        e.stopPropagation();

        const video = videoRef.current;
        if (!video) return;
        video.pause();

        const timelineContainer = e.currentTarget.closest('.timeline-track')?.parentElement;
        if (!timelineContainer) return;
        
        const rect = timelineContainer.getBoundingClientRect();
        
        const onMouseMove = (moveEvent: MouseEvent) => {
            const clientX = moveEvent.clientX;
            const deltaX = clientX - rect.left;
            const ratio = Math.max(0, Math.min(1, deltaX / rect.width));
            const newTime = ratio * duration;

            if (video) video.currentTime = newTime;

            handleUpdateTime(clipId, handleType, newTime);
        };

        const onMouseUp = () => {
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', onMouseUp);
        };

        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
    };

    // Video player controls
    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const handleTimeUpdate = () => {
            setCurrentTime(video.currentTime);
            const currentPreviewId = previewingClipIdRef.current;
            if (currentPreviewId) {
                const allClips = clipsRef.current;
                const previewClip = allClips.find(c => c.id === currentPreviewId);
                if (previewClip && video.currentTime >= previewClip.end - 0.05) {
                    handleStopPreview();
                }
            }
        };
        const handlePlay = () => setIsPlaying(true);
        const handlePause = () => {
            setIsPlaying(false);
            if (previewingClipIdRef.current) {
                setPreviewingClipId(null);
            }
        };
        
        video.addEventListener('timeupdate', handleTimeUpdate);
        video.addEventListener('play', handlePlay);
        video.addEventListener('pause', handlePause);

        return () => {
            video.removeEventListener('timeupdate', handleTimeUpdate);
            video.removeEventListener('play', handlePlay);
            video.removeEventListener('pause', handlePause);
        };
    }, [handleStopPreview]);

    const togglePlayPause = () => {
        const video = videoRef.current;
        if (video) {
            if (previewingClipId) {
                handleStopPreview();
            } else {
                video.paused ? video.play() : video.pause();
            }
        }
    };
    
    return (
        <div className="w-full flex flex-col items-center space-y-4 relative animate-fade-in">
             {isLoading && <Spinner message={loadingMessage} />}
             <style>{`
                .clip-item { transition: all 0.2s ease-in-out; }
                .clip-item-dragging { opacity: 0.5; background-color: rgba(107, 33, 168, 0.2); border: 2px dashed #a855f7; }
                .timeline-track { position: relative; width: 100%; height: 8px; background-color: #374151; border-radius: 9999px; }
                .clip-segment { position: absolute; height: 100%; background-color: #8b5cf6; border-radius: 9999px; z-index: 10; transition: all 0.2s ease-in-out; }
                .trim-handle { position: absolute; top: 50%; width: 16px; height: 24px; background-color: white; border-radius: 4px; border: 2px solid #8b5cf6; cursor: ew-resize; z-index: 20; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 2px; }
                .trim-handle::before, .trim-handle::after { content: ''; width: 2px; height: 8px; background-color: #8b5cf6; border-radius: 1px; }
                .trim-handle.start { left: 0; transform: translate(-50%, -50%); }
                .trim-handle.end { right: 0; transform: translate(50%, -50%); }
                .playback-head { position: absolute; top: 50%; transform: translate(-50%, -50%); width: 3px; height: 32px; background-color: #ef4444; border-radius: 2px; pointer-events: none; z-index: 30; transition: left 0.05s linear; }
                .playback-head::before { content: ''; position: absolute; top: -8px; left: 50%; transform: translateX(-50%); width: 12px; height: 12px; background-color: #ef4444; border-radius: 50%; border: 2px solid white; }
             `}</style>
            <h2 className="text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                Video Editor
            </h2>
             <div className="relative w-full max-w-2xl rounded-lg shadow-lg border border-gray-700 overflow-hidden bg-black">
                <video ref={videoRef} src={videoUrl} className="w-full h-full block" />
                <div className="absolute top-2 left-2 bg-black/50 p-2 rounded-lg font-mono text-sm">
                    {formatTime(currentTime)} / {formatTime(duration)}
                </div>
            </div>
            <div className="flex items-center space-x-4">
                <button onClick={togglePlayPause} className="p-3 bg-gray-700 rounded-full hover:bg-purple-600 transition-colors" title={isPlaying ? 'Pause' : 'Play'}>
                    {isPlaying ? <PauseIcon /> : <PlayIcon />}
                </button>
                 <button onClick={handleSplit} disabled={!activeClipId} className="flex items-center gap-2 px-4 py-2 bg-gray-700 rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Split clip at current playhead position">
                    <ScissorsIcon className="w-5 h-5" /> Split
                </button>
            </div>
            
            <div className="w-full bg-gray-900/50 p-4 rounded-lg border border-gray-700 space-y-3">
                <h3 className="text-lg font-semibold mb-2">Timeline</h3>
                <div className="space-y-4 overflow-y-auto max-h-[20rem] p-1">
                    {clips.map((clip, index) => (
                        <div
                            key={clip.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, index)}
                            onDragEnter={(e) => handleDragEnter(e, index)}
                            onDragEnd={handleDragEnd}
                            onDragOver={(e) => e.preventDefault()}
                            onClick={() => setActiveClipId(clip.id)}
                            className={`clip-item flex flex-col gap-2 p-3 rounded-lg cursor-grab ${
                                activeClipId === clip.id ? 'bg-purple-900/50 border-2 border-purple-500' : 'bg-gray-800 border-2 border-gray-700 hover:border-gray-600'
                            } ${
                                isDragging && dragItem.current === index ? 'clip-item-dragging' : ''
                            }`}
                        >
                            <div className="flex items-center gap-4">
                                <div className="font-bold text-gray-400">{index + 1}</div>
                                <div className="flex-grow grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs text-gray-400">Start</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            max={duration}
                                            value={clip.start.toFixed(2)}
                                            onChange={(e) => handleUpdateTime(clip.id, 'start', parseFloat(e.target.value))}
                                            className="w-full bg-gray-900 border border-gray-600 rounded p-1 text-sm"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs text-gray-400">End</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            max={duration}
                                            value={clip.end.toFixed(2)}
                                            onChange={(e) => handleUpdateTime(clip.id, 'end', parseFloat(e.target.value))}
                                            className="w-full bg-gray-900 border border-gray-600 rounded p-1 text-sm"
                                        />
                                    </div>
                                </div>
                                <div className="flex-shrink-0 flex items-center">
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            (previewingClipId === clip.id && isPlaying) ? handleStopPreview() : handlePreviewClip(clip.id);
                                        }}
                                        className="p-2 text-gray-400 hover:text-white hover:bg-blue-600 rounded-full transition-colors"
                                        title="Preview this clip"
                                    >
                                        {(previewingClipId === clip.id && isPlaying) ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
                                    </button>
                                    <button onClick={(e) => { e.stopPropagation(); handleDelete(clip.id); }} className="p-2 text-gray-400 hover:text-white hover:bg-red-600 rounded-full transition-colors" title="Delete this clip">
                                        <TrashIcon className="w-5 h-5"/>
                                    </button>
                                </div>
                            </div>
                            
                            <div className="relative pt-4 pb-4">
                                <div className="timeline-track">
                                     <div
                                        className="clip-segment"
                                        style={{
                                            left: `${(clip.start / duration) * 100}%`,
                                            width: `${((clip.end - clip.start) / duration) * 100}%`,
                                        }}
                                    >
                                        <div
                                            onMouseDown={(e) => handleTrimMouseDown(e, clip.id, 'start')}
                                            className="trim-handle start"
                                            title="Drag to trim start time"
                                        />
                                        <div
                                            onMouseDown={(e) => handleTrimMouseDown(e, clip.id, 'end')}
                                            className="trim-handle end"
                                            title="Drag to trim end time"
                                        />
                                    </div>
                                    <div
                                        className="playback-head"
                                        style={{ left: `${(currentTime / duration) * 100}%` }}
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="flex items-center justify-center gap-4 mt-4 w-full">
                <button
                    onClick={onCancel}
                    className="px-6 py-2 bg-transparent border-2 border-gray-600 text-gray-300 font-semibold rounded-full hover:bg-gray-700 hover:border-gray-500 transition-colors duration-200"
                    title="Discard changes and exit editor"
                >
                    Cancel
                </button>
                <button
                    onClick={handleExport}
                    disabled={!isReady || clips.length === 0}
                    className="inline-flex items-center justify-center px-8 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold rounded-full hover:from-green-600 hover:to-teal-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Combine and save clips into a new video"
                >
                    Export Video
                </button>
            </div>
        </div>
    );
};
