
import React, { useState, useRef, useEffect } from 'react';
import { VoiceOption } from '../types';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { CheckIcon } from './icons/CheckIcon';

export const voices: { id: VoiceOption; name: string; description: string }[] = [
    { id: 'nova', name: 'Nova', description: 'A clear, engaging female voice.' },
    { id: 'echo', name: 'Echo', description: 'A deep, commanding male voice.' },
    { id: 'fable', name: 'Fable', description: 'A warm, storyteller-style female voice.' },
    { id: 'onyx', name: 'Onyx', description: 'A formal, professional male voice.' },
    { id: 'shimmer', name: 'Shimmer', description: 'A bright, friendly female voice.' },
];

interface VoiceoverSelectorProps {
    selectedVoice: VoiceOption | 'none';
    onVoiceChange: (voice: VoiceOption | 'none') => void;
    disabled: boolean;
}

export const VoiceoverSelector: React.FC<VoiceoverSelectorProps> = ({ selectedVoice, onVoiceChange, disabled }) => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (voiceId: VoiceOption | 'none') => {
        onVoiceChange(voiceId);
        setIsOpen(false);
    };
    
    return (
        <div className="relative" ref={menuRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                disabled={disabled}
                className="flex items-center justify-center h-10 w-10 bg-gray-700 rounded-full text-gray-300 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500 transition-all duration-200 transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed"
                title="Select AI Voiceover"
                aria-haspopup="true"
                aria-expanded={isOpen}
            >
                <MicrophoneIcon className="w-5 h-5" />
            </button>
            {isOpen && (
                <div className="absolute bottom-12 right-0 w-72 bg-gray-800 border border-gray-700 rounded-lg shadow-lg z-10 animate-fade-in-up">
                    <div className="p-2">
                        <p className="text-sm font-semibold text-gray-200 px-2 pb-2">AI Voiceover</p>
                        <ul className="space-y-1">
                             <li>
                                <button
                                    onClick={() => handleSelect('none')}
                                    className={`w-full text-left p-2 rounded-md hover:bg-gray-700 transition-colors duration-150 ${selectedVoice === 'none' ? 'bg-purple-900/50' : ''}`}
                                >
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium text-gray-100">None</span>
                                        {selectedVoice === 'none' && <CheckIcon className="w-5 h-5 text-purple-400 flex-shrink-0 ml-2" />}
                                    </div>
                                </button>
                            </li>
                            {voices.map((voice) => (
                                <li key={voice.id}>
                                    <button
                                        onClick={() => handleSelect(voice.id)}
                                        className={`w-full text-left p-2 rounded-md hover:bg-gray-700 transition-colors duration-150 ${selectedVoice === voice.id ? 'bg-purple-900/50' : ''}`}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex flex-col">
                                                <span className="text-sm font-medium text-gray-100">{voice.name}</span>
                                                <span className="text-xs text-gray-400">{voice.description}</span>
                                            </div>
                                            {selectedVoice === voice.id && <CheckIcon className="w-5 h-5 text-purple-400 flex-shrink-0 ml-2" />}
                                        </div>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            )}
            <style>{`
                @keyframes fade-in-up { 0% { opacity: 0; transform: translateY(10px); } 100% { opacity: 1; transform: translateY(0); } }
                .animate-fade-in-up { animation: fade-in-up 0.2s ease-out; }
            `}</style>
        </div>
    );
};