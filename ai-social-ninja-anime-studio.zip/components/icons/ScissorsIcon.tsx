
import React from 'react';

export const ScissorsIcon: React.FC<{ className?: string }> = ({ className = "h-6 w-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M7.848 8.25l1.536.887M7.848 8.25a3 3 0 1 0 0 5.25h.003m.001-5.25a3 3 0 1 1 0 5.25m0-5.25 1.536.887m-1.536-.887a3 3 0 0 0-5.25 0l-1.537.887m1.537-.887L1.5 6.75m6.348 1.5 1.536.887m-1.536-.887 1.536-.887m11.152 8.25-1.536-.887m1.536.887a3 3 0 1 0 0-5.25h-.003m.001 5.25a3 3 0 1 1 0-5.25m0 5.25-1.536-.887m1.536.887a3 3 0 0 0 5.25 0l1.537-.887m-1.537.887L22.5 17.25m-6.348-1.5-1.536-.887m1.536.887-1.536.887" />
    </svg>
);
