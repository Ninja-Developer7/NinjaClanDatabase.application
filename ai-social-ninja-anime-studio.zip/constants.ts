
import { PromptTemplateSlotKey } from './types';

export const ACCEPTED_FILE_TYPES = {
    'image/jpeg': ['.jpg', '.jpeg'],
    'image/png': ['.png'],
    'image/gif': ['.gif'],
    'video/mp4': ['.mp4'],
    'video/quicktime': ['.mov'],
};

export const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25 MB

export const PROMPT_TEMPLATE_SLOTS: { key: PromptTemplateSlotKey; label: string }[] = [
    { key: 'protagonist', label: 'Character Protagonist' },
    { key: 'antagonist', label: 'Character Antagonist' },
    { key: 'environment', label: 'Environment' },
    { key: 'background', label: 'Background' },
    { key: 'foreground', label: 'Foreground' },
    { key: 'scene', label: 'Scene Reference' },
];

export const LOADING_MESSAGES = [
    'Initializing AI model...',
    'Analyzing your prompt and visual reference...',
    'Storyboarding the main scenes...',
    'Generating primary motion vectors...',
    'Applying Studio Ghibli art style...',
    'Rendering keyframes in high definition...',
    'Compositing anime-style effects...',
    'Encoding final video file...',
    'This is taking a bit longer than expected, but we are still working on it...',
    'Finalizing... Your masterpiece is almost ready!'
];
