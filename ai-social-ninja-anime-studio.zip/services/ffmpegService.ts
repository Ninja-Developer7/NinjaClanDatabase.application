declare const FFmpeg: any;

let ffmpegInstance: any = null;

export const loadFFmpeg = async (): Promise<any> => {
    if (ffmpegInstance) {
        return ffmpegInstance;
    }
    const ffmpeg = new FFmpeg.FFmpeg();
    ffmpeg.on('log', ({ message }: { message: string }) => {
        console.log("FFMPEG:", message);
    });
    await ffmpeg.load({
        coreURL: "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js"
    });
    ffmpegInstance = ffmpeg;
    return ffmpegInstance;
};

export const mergeVideoAndAudio = async (
    ffmpeg: any,
    videoBlob: Blob,
    audioBlob: Blob,
    onProgress: (message: string) => void
): Promise<Blob> => {
    onProgress('Writing files to FFmpeg memory...');
    await ffmpeg.writeFile('input.mp4', await FFmpeg.fetchFile(videoBlob));
    await ffmpeg.writeFile('input.webm', await FFmpeg.fetchFile(audioBlob));

    onProgress('Executing FFmpeg command...');
    // -c:v copy: copies the video stream without re-encoding
    // -c:a aac: encodes the audio to AAC, a widely compatible format
    // -shortest: finishes encoding when the shortest input stream ends (the video)
    await ffmpeg.exec([
        '-i', 'input.mp4',
        '-i', 'input.webm',
        '-c:v', 'copy',
        '-c:a', 'aac',
        '-shortest',
        'output.mp4'
    ]);

    onProgress('Reading output file...');
    const data = await ffmpeg.readFile('output.mp4');
    const newBlob = new Blob([(data as Uint8Array).buffer], { type: 'video/mp4' });

    return newBlob;
};
