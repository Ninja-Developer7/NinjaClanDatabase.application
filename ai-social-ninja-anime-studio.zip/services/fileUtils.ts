

export const fileToGenerativePart = async (file: File) => {
    const base64EncodedData = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result.split(',')[1]);
            } else {
                reject(new Error("Failed to read file as base64 string."));
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });

    return {
        imageBytes: base64EncodedData,
        mimeType: file.type,
    };
};

const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result);
            } else {
                reject(new Error("Failed to read file as data URL."));
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
};


/**
 * Extracts a single frame from a video file and returns its base64 representation.
 * @param videoFile The video file to process.
 * @returns A promise that resolves to an object containing the base64-encoded image data and its MIME type.
 */
export const extractFrameFromVideo = (videoFile: File): Promise<{ base64: string; mimeType: string; dataUrl: string; }> => {
    return new Promise((resolve, reject) => {
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.src = URL.createObjectURL(videoFile);
        video.muted = true;
        video.playsInline = true;

        const cleanup = () => {
            URL.revokeObjectURL(video.src);
        };

        video.onloadedmetadata = () => {
            video.currentTime = video.duration * 0.25;
        };

        video.onseeked = () => {
            setTimeout(() => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    cleanup();
                    return reject(new Error("Could not get canvas context."));
                }
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                const base64EncodedData = dataUrl.split(',')[1];
                cleanup();

                if (!base64EncodedData) {
                    return reject(new Error("Failed to extract frame from video canvas."));
                }
                
                resolve({
                    base64: base64EncodedData,
                    mimeType: 'image/jpeg',
                    dataUrl: dataUrl
                });
            }, 100);
        };

        video.onerror = (e) => {
            cleanup();
            console.error("Video processing error:", e);
            reject(new Error("Error processing video. It may be corrupt or in an unsupported format."));
        };

        video.play().catch(() => {});
    });
};


/**
 * Converts a Blob to a File object.
 * @param theBlob The blob to convert.
 * @param fileName The name for the new file.
 * @returns The new File object.
 */
const blobToFile = (theBlob: Blob, fileName: string): File => {
    return new File([theBlob], fileName, {
        lastModified: new Date().getTime(),
        type: theBlob.type
    });
};


/**
 * Extracts the last frame from a video blob and returns it as a File.
 * @param videoBlob The video blob to process.
 * @returns A promise that resolves to a File object of the last frame.
 */
export const extractLastFrameFromVideo = (videoBlob: File | Blob): Promise<File> => {
    return new Promise((resolve, reject) => {
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.src = URL.createObjectURL(videoBlob);
        video.muted = true;
        video.playsInline = true;

        const cleanup = () => {
            URL.revokeObjectURL(video.src);
        };

        video.onloadedmetadata = () => {
            // Seek to a point very close to the end of the video.
            // Seeking to the exact 'duration' can be unreliable in some browsers.
            video.currentTime = video.duration > 0.1 ? video.duration - 0.1 : 0;
        };

        video.onseeked = () => {
            // A short timeout can help ensure the frame is fully rendered after seeking.
            setTimeout(() => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    cleanup();
                    return reject(new Error("Could not get canvas context."));
                }
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                canvas.toBlob((blob) => {
                    cleanup();
                    if (!blob) {
                        return reject(new Error("Failed to create blob from canvas."));
                    }
                    const frameFile = blobToFile(blob, 'last_frame.jpg');
                    resolve(frameFile);
                }, 'image/jpeg', 0.9); // Use high quality for the reference frame
            }, 100);
        };

        video.onerror = (e) => {
            cleanup();
            console.error("Video processing error:", e);
            reject(new Error("Error processing video for frame extraction."));
        };
        
        // Start playing to enable seeking in some environments
        video.play().catch(() => {});
    });
};

/**
 * Creates a data URL thumbnail for a given file (image or video).
 * @param file The file to create a thumbnail for.
 * @returns A promise that resolves to a data URL string.
 */
export const createThumbnail = async (file: File): Promise<string> => {
    if (file.type.startsWith('image/')) {
        return fileToDataURL(file);
    } else if (file.type.startsWith('video/')) {
        const { dataUrl } = await extractFrameFromVideo(file);
        return dataUrl;
    } else {
        throw new Error("Unsupported file type for thumbnail generation.");
    }
};
