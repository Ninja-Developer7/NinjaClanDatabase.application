
import { GoogleGenAI } from "@google/genai";
import { fileToGenerativePart, extractFrameFromVideo } from './fileUtils';
import { ArtisticStyle, VoiceOption } from '../types';

/**
 * Parses Gemini API errors and returns a user-friendly error object.
 * @param error The error object from the API call.
 * @param context A string indicating when the error occurred ('initial' request or during 'operation').
 * @returns An Error object with a user-friendly message.
 */
const handleGeminiError = (error: any, context: 'initial' | 'operation'): Error => {
    const message = (context === 'initial' ? error.message : error.message) || 'An unknown error occurred.';
    const lowerMessage = message.toLowerCase();

    // Safety and Policy Violations
    if (lowerMessage.includes('sensitive') || lowerMessage.includes('responsible ai') || lowerMessage.includes('policy') || lowerMessage.includes('safety')) {
        return new Error("Your prompt or media may contain sensitive content. Please adjust it to comply with our safety policies and try again.");
    }

    // Invalid Argument / Bad Request
    if (lowerMessage.includes('invalid argument') || lowerMessage.includes('bad request')) {
        if (lowerMessage.includes('prompt')) {
            return new Error("The prompt is too complex or contains unsupported elements. Please try simplifying your request.");
        }
        if (lowerMessage.includes('image') || lowerMessage.includes('media')) {
            return new Error("The provided visual reference is unsupported or could not be processed. Please try a different file format like JPG or PNG.");
        }
        return new Error("There was an issue with the request. Please check your prompt and media, then try again.");
    }

    // Resource/Quota Errors
    if (lowerMessage.includes('quota') || lowerMessage.includes('resource_exhausted')) {
        return new Error("The service is experiencing high demand. Please wait a few moments and try again.");
    }
    
    // Internal Server Errors
    if (lowerMessage.includes('internal') || lowerMessage.includes('unavailable')) {
        return new Error("A temporary issue occurred on our end. Please wait a moment and try generating your video again.");
    }

    // Fallback for operation errors to avoid being too generic
    if (context === 'operation') {
        return new Error(`Video generation failed: ${message}`);
    }
    
    // Default fallback
    return error instanceof Error ? error : new Error(message);
};


/**
 * Uses a text model to expand a user's prompt with rich environmental details.
 * @param prompt The user's original prompt.
 * @returns A promise that resolves to a detailed scenery description string.
 */
const generateSceneryDescription = async (prompt: string): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: `You are an expert anime world-builder and concept artist. Your task is to expand a simple user prompt into a rich, detailed description of the background, environment, and atmosphere. Focus ONLY on the scenery, not character actions. Describe lighting, weather, key landmarks, and the overall mood. Be concise and descriptive, providing 2-3 detailed sentences. Do not repeat the user's prompt.

            Example User Prompt: "A ninja fighting a dragon on a bridge."
            Your Output: "The scene is set on a weathered rope bridge swaying precariously over a deep, mist-filled chasm. Ancient, moss-covered statues of forgotten gods line the canyon walls. The air is thick with the smell of ozone from an approaching storm, and occasional flashes of lightning illuminate the swirling fog below."`,
            // Disable thinking for faster, more direct responses for this specific task
            thinkingConfig: { thinkingBudget: 0 },
        },
    });

    return response.text;
};

/**
 * Analyzes multiple images of a character and generates a cohesive textual description.
 * @param files An array of image files for the character reference.
 * @returns A promise that resolves to a detailed character description string.
 */
const generateCharacterDescriptionFromImages = async (files: File[]): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const imageParts = await Promise.all(files.map(file => fileToGenerativePart(file)));
    
    const textPart = {
        text: `Analyze these character reference images. Create a single, cohesive, and detailed description of the character suitable for an animation prompt. Focus on consistent physical traits:
- Face: Shape, eyes (color, shape), nose, mouth.
- Hair: Color, style, length, texture.
- Build: Body type, height.
- Clothing: Detailed description of their full outfit, including colors, style, and layers.
- Key Accessories: Any important items they have (e.g., glasses, jewelry, weapons).
Synthesize all images into one definitive character sheet.`
    };
    
    // FIX: The `generateContent` API requires a specific structure for image parts (`{ inlineData: { data, mimeType } }`).
    // The `imageParts` array, which is in a format for a different API (`generateVideos`), is mapped to this structure.
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [
            textPart,
            ...imageParts.map(part => ({
                inlineData: {
                    data: part.imageBytes,
                    mimeType: part.mimeType,
                }
            }))
        ] },
        config: {
            // Disable thinking for faster, more direct responses for this specific task
            thinkingConfig: { thinkingBudget: 0 },
        },
    });

    return `Character Description: ${response.text}\n\n`;
};


const getStyleDescription = (style: ArtisticStyle): string => {
    switch (style) {
        case 'shonen-action':
            return `**Primary Style:** A dynamic, high-energy Shonen style. Emphasize sharp lines, intense action sequences, dramatic close-ups, and explosive energy effects.\n**Secondary Influences:** Draw inspiration from the visual language of series like Dragon Ball Z, Naruto, and Jujutsu Kaisen for impactful combat and motion.`;
        case 'shojo-romance':
            return `**Primary Style:** A soft and dreamy Shojo aesthetic. Focus on expressive, large eyes, elegant character designs, and a pastel color palette. Use gentle lighting, floral motifs, and sparkling effects to create a romantic and emotional atmosphere.\n**Secondary Influences:** Evoke the feeling of classic Shojo manga and anime.`;
        case 'cyberpunk-grit':
            return `**Primary Style:** A dark, gritty Cyberpunk anime style. Feature neon-drenched, rainy cityscapes, detailed cybernetic enhancements, and a high-contrast, moody lighting scheme.\n**Secondary Influences:** Take cues from iconic works like Akira and Ghost in the Shell for a high-tech, dystopian feel.`;
        case 'fantasy-epic':
            return `**Primary Style:** A grand, high-fantasy anime aesthetic. Create epic landscapes, detailed armor and weaponry, and awe-inspiring magical effects. Emphasize a sense of scale and adventure.\n**Secondary Influences:** Draw from fantasy series like Berserk and Record of Lodoss War.`;
        case 'retro-anime':
            return `**Primary Style:** A classic Retro Anime aesthetic from the late 80s and 90s. Utilize hand-drawn cel-shading, distinct line art, film grain, and a slightly muted color palette to evoke nostalgia.\n**Secondary Influences:** Draw inspiration from iconic series like Cowboy Bebop, Evangelion, and Sailor Moon.`;
        case 'default-studio':
        default:
            return `**Primary Style:** Emulate the aesthetic of Studio Ghibli, focusing on lush, painted backgrounds, whimsical character design, and a sense of wonder.\n**Secondary Influences:** Infuse the action and dynamic art styles of classic anime like Naruto, Ninja Scroll, Dragon Ball Z, and One Piece for motion and impact.`;
    }
};


const constructPrompt = (userPrompt: string, videoQuality: '720p' | '1080p', artisticStyle: ArtisticStyle): string => {
    const resolution = videoQuality === '1080p' ? 'high-definition (1080p)' : 'standard-definition (720p)';
    const styleDescription = getStyleDescription(artisticStyle);
    return `Create a 15-second, silent, ${resolution} video.
    ${styleDescription}
    **Core Scene:** ${userPrompt}
    Ensure the final output is a complete, seamless 15-second .mp4 video.`;
};

export const generateVideo = async (
    prompt: string,
    visualReferences: File[],
    videoQuality: '720p' | '1080p',
    enhanceScenery: boolean,
    artisticStyle: ArtisticStyle,
    onProgress: (stepName: string, progress?: number) => void
): Promise<{ videoUrl: string, videoBlob: Blob }> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    let finalUserPrompt = prompt;
    let characterDescription = '';

    // If more than one image is provided, generate a text description to unify them.
    if (visualReferences.length > 1) {
        onProgress('Analyzing References');
        try {
            // Filter to ensure only images are sent for description generation
            const imageFiles = visualReferences.filter(f => f.type.startsWith('image/'));
            if (imageFiles.length > 1) {
                 characterDescription = await generateCharacterDescriptionFromImages(imageFiles);
            }
        } catch (err) {
            console.error("Character description generation failed, proceeding without it.", err);
            // Non-critical failure, proceed without the detailed description.
        }
    }

    if (enhanceScenery && prompt) {
        onProgress('Enhancing Scene');
        try {
            const sceneryDescription = await generateSceneryDescription(prompt);
            // Combine prompt and description for a richer scene
            finalUserPrompt = `${prompt}. Scene details: ${sceneryDescription}`;
        } catch (err) {
            console.error("Scenery enhancement failed, proceeding with original prompt.", err);
            // Non-critical failure, so we proceed with the original prompt
        }
    }
    
    // Prepend the generated character description to the final prompt
    const fullPrompt = constructPrompt(`${characterDescription}${finalUserPrompt}`, videoQuality, artisticStyle);

    const generateVideosParams: any = {
        model: 'veo-2.0-generate-001',
        prompt: fullPrompt,
        config: {
            numberOfVideos: 1,
        }
    };
    
    // The video model API only accepts a single image reference.
    // So we only provide one if exactly one reference was given by the user.
    const singleReference = visualReferences.length === 1 ? visualReferences[0] : null;

    if (singleReference) {
        onProgress('Processing Media');
        if (singleReference.type.startsWith('image/')) {
            generateVideosParams.image = await fileToGenerativePart(singleReference);
        } else if (singleReference.type.startsWith('video/')) {
            try {
                const frameData = await extractFrameFromVideo(singleReference);
                generateVideosParams.image = {
                    imageBytes: frameData.base64,
                    mimeType: frameData.mimeType,
                };
            } catch (err) {
                console.error("Failed to extract frame from video:", err);
                throw new Error("Could not process the uploaded video file. Please try a different video or an image.");
            }
        }
    }

    onProgress('Sending Request');
    let operation;
    try {
        operation = await ai.models.generateVideos(generateVideosParams);
    } catch (err: any) {
        throw handleGeminiError(err, 'initial');
    }

    onProgress('Generating Video', 0);
    let lastProgress = 0;
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000)); // Poll more frequently for progress updates
        operation = await ai.operations.getVideosOperation({ operation: operation });

        // Assume the operation object contains progress metadata. This is a common pattern for Google Cloud long-running operations.
        const progress = (operation.metadata?.progressPercent as number) || lastProgress;
        if (progress > lastProgress) {
            onProgress('Generating Video', progress);
            lastProgress = progress;
        }
    }

    if (operation.error) {
        throw handleGeminiError(operation.error, 'operation');
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

    if (!downloadLink) {
        // This case can happen if the operation succeeds but contains no video, often due to a safety policy flag.
        // We throw a more specific error here.
        throw new Error("Generation completed, but no video was returned. This often happens if the prompt is flagged for safety. Please revise your prompt and try again.");
    }

    onProgress('Finalizing');
    const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    if (!videoResponse.ok) {
        throw new Error(`Failed to download the generated video. Status: ${videoResponse.statusText}`);
    }

    const videoBlob = await videoResponse.blob();
    const videoUrl = URL.createObjectURL(videoBlob);
    
    return { videoUrl, videoBlob };
};

/**
 * Generates a voiceover from text using the browser's Speech Synthesis API.
 * @param text The text to be spoken.
 * @param voice The selected voice option.
 * @returns A promise that resolves to an audio Blob.
 */
export const generateVoiceover = (text: string, voice: VoiceOption): Promise<Blob> => {
    return new Promise((resolve, reject) => {
        if (!window.speechSynthesis) {
            return reject(new Error("Your browser does not support Speech Synthesis."));
        }

        // Map our voice names to potential voice names in the browser
        const voiceMap: Record<VoiceOption, string[]> = {
            'nova': ['nova', 'zira', 'samantha', 'google us english'],
            'echo': ['echo', 'david', 'microsoft david'],
            'fable': ['fable', 'google UK english female', 'hazel'],
            'onyx': ['onyx', 'google UK english male', 'susan'],
            'shimmer': ['shimmer', 'google español', 'helena']
        };

        const utterance = new SpeechSynthesisUtterance(text);
        
        const voices = window.speechSynthesis.getVoices();
        const selectedVoice = voices.find(v => 
            voiceMap[voice].some(keyword => v.name.toLowerCase().includes(keyword))
        );

        if (selectedVoice) {
            utterance.voice = selectedVoice;
        } else {
            console.warn(`Could not find a specific voice for "${voice}". Using browser default.`);
        }
        
        // Use Web Audio API to capture the speech output
        const audioContext = new AudioContext();
        const dest = audioContext.createMediaStreamDestination();
        const mediaRecorder = new MediaRecorder(dest.stream, { mimeType: 'audio/webm' });

        const chunks: Blob[] = [];
        mediaRecorder.ondataavailable = (event) => {
            chunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(chunks, { type: 'audio/webm' });
            resolve(audioBlob);
            audioContext.close();
        };
        
        utterance.onend = () => {
            mediaRecorder.stop();
        };

        utterance.onerror = (event) => {
            reject(new Error(`Speech synthesis error: ${event.error}`));
            audioContext.close();
        };

        // Connect the utterance to our destination
        const source = audioContext.createMediaStreamSource(dest.stream); // This is a bit of a hack to keep the context alive
        source.connect(audioContext.destination);

        // Start the process
        mediaRecorder.start();
        window.speechSynthesis.speak(utterance);
    });
};