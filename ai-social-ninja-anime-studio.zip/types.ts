
import { VideoQuality } from './components/QualitySelector';

export type ArtisticStyle = 'default-studio' | 'shonen-action' | 'shojo-romance' | 'cyberpunk-grit' | 'fantasy-epic' | 'retro-anime';

export type VoiceOption = 'nova' | 'echo' | 'fable' | 'onyx' | 'shimmer';

export interface VisualReferenceFile {
    file: File;
    previewUrl: string;
}

export interface HistoryMetadata {
  id: string;
  prompt: string;
  timestamp: number;
  visualReferenceThumbnail?: string; // Data URL of the thumbnail
  quality: VideoQuality;
  artisticStyle: ArtisticStyle;
  voice: VoiceOption | 'none';
}

// New types for structured prompt
export type PromptTemplateSlotKey = 'protagonist' | 'antagonist' | 'environment' | 'background' | 'foreground' | 'scene';

export type PromptImages = Partial<Record<PromptTemplateSlotKey, VisualReferenceFile>>;
